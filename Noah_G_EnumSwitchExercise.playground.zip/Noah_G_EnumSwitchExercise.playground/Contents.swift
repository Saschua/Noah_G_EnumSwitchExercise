import UIKit

enum sandwich {
    case bacon
    case cheese
    case lettuce
    case tommato
    case wheatBread
    case mayonaise
}
print; sandwich.bacon
print; sandwich.cheese
print; sandwich.lettuce
print; sandwich.tommato
print; sandwich.wheatBread
print; sandwich.mayonaise
